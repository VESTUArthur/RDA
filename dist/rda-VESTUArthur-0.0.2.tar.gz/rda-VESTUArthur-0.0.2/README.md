# Rhythmic Data Analysis
Include a class RhythmicDataAnalysis with methods that allow the user to perform rhythmic data analysis (LS, ARS, JTK, Cosinor, RAIN)
